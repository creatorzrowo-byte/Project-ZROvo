# Project ZROvo — v0.2.0 preview source

An early native Android editor prototype.

## Working in this preview
- Dark ZROvo editor interface
- Multi-select image/video import using Android's system file picker
- Image preview
- Video preview with looping playback
- Timeline tiles for imported media
- Tap a timeline tile to select and preview that item
- Remove the selected timeline item
- ARM64 (`arm64-v8a`) APK configuration
- GitHub Actions workflow for a debug APK

## Not implemented yet
- True multi-track timeline and clip trimming/splitting
- Keyframes and animation controls
- Transitions, effects and filters
- Audio tracks and text overlays
- Video rendering/export (including 120 FPS)

The Export button is intentionally a placeholder. This build does not export videos yet.

## Build using GitHub Actions
1. Create a GitHub repository and upload the contents of this folder.
2. Open the repository's **Actions** tab.
3. Select **Build Project ZROvo APK** and run the workflow.
4. Download the `Project-ZROvo-debug` artifact when the workflow succeeds.
5. Extract the ZIP to get `app-debug.apk`.

## Local build
Requires JDK 17 and Android SDK Platform 35:
`gradle assembleDebug`

Package: `com.zrovo.editor`
Minimum Android: 8.0 (API 26)
Target Android: 15 (API 35)

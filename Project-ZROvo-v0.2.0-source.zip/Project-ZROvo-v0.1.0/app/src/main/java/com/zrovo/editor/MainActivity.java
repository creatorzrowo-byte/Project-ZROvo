package com.zrovo.editor;

import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.VideoView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final int PICK_MEDIA = 41;

    private final int bg = Color.rgb(9, 11, 18);
    private final int panel = Color.rgb(20, 23, 34);
    private final int muted = Color.rgb(151, 157, 178);
    private final int white = Color.WHITE;
    private final int purple = Color.rgb(155, 123, 255);

    private final List<MediaItem> clips = new ArrayList<>();
    private FrameLayout previewFrame;
    private LinearLayout timeline;
    private TextView clipCount;
    private TextView emptyTimeline;
    private TextView previewHint;
    private int selectedIndex = -1;
    private VideoView activeVideo;

    private static class MediaItem {
        final Uri uri;
        final String mime;
        final String label;

        MediaItem(Uri uri, String mime) {
            this.uri = uri;
            this.mime = mime == null ? "" : mime;
            this.label = this.mime.startsWith("video/") ? "VIDEO" : "PHOTO";
        }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        buildScreen();
    }

    private void buildScreen() {
        ScrollView page = new ScrollView(this);
        page.setFillViewport(true);
        page.setBackgroundColor(bg);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(14), dp(18), dp(22));
        page.addView(root);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand = text("ZROvo", 25, white, true);
        top.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        TextView version = text("BETA 0.2", 11, muted, true);
        version.setPadding(dp(10), dp(7), dp(10), dp(7));
        version.setBackground(round(panel, 18));
        top.addView(version);
        root.addView(top);

        TextView tagline = text("Create something unreal.", 13, muted, false);
        LinearLayout.LayoutParams tagLp = new LinearLayout.LayoutParams(-1, -2);
        tagLp.topMargin = dp(4);
        tagLp.bottomMargin = dp(18);
        root.addView(tagline, tagLp);

        TextView projectTitle = text("PREVIEW", 11, muted, true);
        projectTitle.setLetterSpacing(0.16f);
        root.addView(projectTitle);

        previewFrame = new FrameLayout(this);
        previewFrame.setBackground(round(Color.rgb(4, 5, 9), 18));
        LinearLayout.LayoutParams previewLp = new LinearLayout.LayoutParams(-1, dp(230));
        previewLp.topMargin = dp(10);
        root.addView(previewFrame, previewLp);

        previewHint = text("Add photos or videos to see your preview", 14, muted, false);
        previewHint.setGravity(Gravity.CENTER);
        previewFrame.addView(previewHint, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout controls = new LinearLayout(this);
        controls.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams controlsLp = new LinearLayout.LayoutParams(-1, -2);
        controlsLp.topMargin = dp(12);
        root.addView(controls, controlsLp);

        Button add = button("+ Add media", purple, white);
        controls.addView(add, new LinearLayout.LayoutParams(0, dp(46), 1));
        add.setOnClickListener(v -> openPicker());

        Button remove = button("Remove", Color.rgb(39, 43, 59), white);
        LinearLayout.LayoutParams removeLp = new LinearLayout.LayoutParams(dp(105), dp(46));
        removeLp.leftMargin = dp(9);
        controls.addView(remove, removeLp);
        remove.setOnClickListener(v -> removeSelected());

        Button export = button("Export", Color.rgb(39, 43, 59), white);
        LinearLayout.LayoutParams exportLp = new LinearLayout.LayoutParams(dp(92), dp(46));
        exportLp.leftMargin = dp(9);
        controls.addView(export, exportLp);
        export.setOnClickListener(v -> Toast.makeText(this,
                "Video export is not implemented in this preview build yet.",
                Toast.LENGTH_LONG).show());

        LinearLayout timelineCard = new LinearLayout(this);
        timelineCard.setOrientation(LinearLayout.VERTICAL);
        timelineCard.setPadding(dp(13), dp(13), dp(13), dp(13));
        timelineCard.setBackground(round(panel, 18));
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(-1, -2);
        tlp.topMargin = dp(18);
        root.addView(timelineCard, tlp);

        LinearLayout timelineHeader = new LinearLayout(this);
        timelineHeader.setGravity(Gravity.CENTER_VERTICAL);
        TextView timelineLabel = text("TIMELINE", 11, muted, true);
        timelineLabel.setLetterSpacing(0.14f);
        timelineHeader.addView(timelineLabel, new LinearLayout.LayoutParams(0, -2, 1));
        clipCount = text("0 clips", 11, muted, false);
        timelineHeader.addView(clipCount);
        timelineCard.addView(timelineHeader);

        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout.LayoutParams hsLp = new LinearLayout.LayoutParams(-1, dp(92));
        hsLp.topMargin = dp(12);
        timelineCard.addView(hs, hsLp);

        timeline = new LinearLayout(this);
        timeline.setOrientation(LinearLayout.HORIZONTAL);
        hs.addView(timeline);

        emptyTimeline = text("Your timeline is empty", 12, muted, false);
        emptyTimeline.setGravity(Gravity.CENTER);
        timeline.addView(emptyTimeline, new LinearLayout.LayoutParams(-1, dp(76)));

        TextView toolsTitle = text("QUICK TOOLS", 11, muted, true);
        toolsTitle.setLetterSpacing(0.14f);
        LinearLayout.LayoutParams toolTitleLp = new LinearLayout.LayoutParams(-1, -2);
        toolTitleLp.topMargin = dp(20);
        root.addView(toolsTitle, toolTitleLp);

        LinearLayout tools = new LinearLayout(this);
        tools.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams toolsLp = new LinearLayout.LayoutParams(-1, -2);
        toolsLp.topMargin = dp(10);
        root.addView(tools, toolsLp);
        addTool(tools, "Text", "Aa");
        addTool(tools, "Audio", "♫");
        addTool(tools, "Effects", "✦");
        addTool(tools, "Filters", "◐");

        TextView note = text("Preview build • Editing and export tools are in development", 11, muted, false);
        note.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams noteLp = new LinearLayout.LayoutParams(-1, -2);
        noteLp.topMargin = dp(22);
        root.addView(note, noteLp);

        setContentView(page);
    }

    private void addTool(LinearLayout parent, String label, String symbol) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setGravity(Gravity.CENTER);
        item.setPadding(dp(4), dp(12), dp(4), dp(12));
        item.setBackground(round(panel, 14));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(76), 1);
        lp.rightMargin = dp(7);
        parent.addView(item, lp);
        item.addView(text(symbol, 21, purple, true));
        TextView name = text(label, 11, white, false);
        LinearLayout.LayoutParams nameLp = new LinearLayout.LayoutParams(-2, -2);
        nameLp.topMargin = dp(5);
        item.addView(name, nameLp);
        item.setOnClickListener(v -> Toast.makeText(this,
                label + " tools are planned for a future build.", Toast.LENGTH_SHORT).show());
    }

    private void openPicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"image/*", "video/*"});
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, PICK_MEDIA);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_MEDIA || resultCode != Activity.RESULT_OK || data == null) return;

        ClipData clipData = data.getClipData();
        if (clipData != null) {
            for (int i = 0; i < clipData.getItemCount(); i++) {
                addPickedUri(clipData.getItemAt(i).getUri());
            }
        } else if (data.getData() != null) {
            addPickedUri(data.getData());
        }

        if (!clips.isEmpty() && selectedIndex < 0) selectClip(0);
        refreshTimeline();
    }

    private void addPickedUri(Uri uri) {
        if (uri == null) return;
        for (MediaItem existing : clips) {
            if (existing.uri.equals(uri)) return;
        }
        try {
            getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) { }
        String mime = getContentResolver().getType(uri);
        if (mime == null || (!mime.startsWith("image/") && !mime.startsWith("video/"))) {
            Toast.makeText(this, "Unsupported file: " + uri.getLastPathSegment(), Toast.LENGTH_SHORT).show();
            return;
        }
        clips.add(new MediaItem(uri, mime));
    }

    private void selectClip(int index) {
        if (index < 0 || index >= clips.size()) return;
        selectedIndex = index;
        MediaItem item = clips.get(index);
        previewFrame.removeAllViews();
        activeVideo = null;

        if (item.mime.startsWith("video/")) {
            VideoView video = new VideoView(this);
            activeVideo = video;
            previewFrame.addView(video, new FrameLayout.LayoutParams(-1, -1));
            video.setVideoURI(item.uri);
            video.setOnPreparedListener(mp -> {
                mp.setLooping(true);
                video.start();
            });
            video.setOnErrorListener((mp, what, extra) -> {
                showPreviewMessage("Couldn't play this video");
                return true;
            });
        } else {
            ImageView image = new ImageView(this);
            image.setScaleType(ImageView.ScaleType.FIT_CENTER);
            image.setImageURI(item.uri);
            previewFrame.addView(image, new FrameLayout.LayoutParams(-1, -1));
        }
        refreshTimeline();
    }

    private void showPreviewMessage(String message) {
        previewFrame.removeAllViews();
        TextView hint = text(message, 14, muted, false);
        hint.setGravity(Gravity.CENTER);
        previewFrame.addView(hint, new FrameLayout.LayoutParams(-1, -1));
    }

    private void removeSelected() {
        if (selectedIndex < 0 || selectedIndex >= clips.size()) {
            Toast.makeText(this, "Select a timeline clip first.", Toast.LENGTH_SHORT).show();
            return;
        }
        clips.remove(selectedIndex);
        if (clips.isEmpty()) {
            selectedIndex = -1;
            previewFrame.removeAllViews();
            previewHint = text("Add photos or videos to see your preview", 14, muted, false);
            previewHint.setGravity(Gravity.CENTER);
            previewFrame.addView(previewHint, new FrameLayout.LayoutParams(-1, -1));
        } else {
            selectClip(Math.min(selectedIndex, clips.size() - 1));
        }
        refreshTimeline();
    }

    private void refreshTimeline() {
        timeline.removeAllViews();
        clipCount.setText(clips.size() + (clips.size() == 1 ? " clip" : " clips"));
        if (clips.isEmpty()) {
            emptyTimeline = text("Your timeline is empty", 12, muted, false);
            emptyTimeline.setGravity(Gravity.CENTER);
            timeline.addView(emptyTimeline, new LinearLayout.LayoutParams(-1, dp(76)));
            return;
        }
        for (int i = 0; i < clips.size(); i++) {
            final int index = i;
            MediaItem item = clips.get(i);
            TextView tile = text(item.label + "\n" + (i + 1), 10, white, true);
            tile.setGravity(Gravity.CENTER);
            tile.setBackground(round(i == selectedIndex ? Color.rgb(91, 67, 151) : Color.rgb(49, 43, 77), 10));
            tile.setElevation(i == selectedIndex ? dp(3) : 0);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(86), dp(76));
            lp.rightMargin = dp(8);
            timeline.addView(tile, lp);
            tile.setOnClickListener(v -> selectClip(index));
        }
    }

    @Override protected void onPause() {
        if (activeVideo != null && activeVideo.isPlaying()) activeVideo.pause();
        super.onPause();
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private Button button(String label, int color, int textColor) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(textColor);
        b.setTextSize(12);
        b.setAllCaps(false);
        b.setPadding(dp(4), 0, dp(4), 0);
        b.setBackground(round(color, 14));
        return b;
    }

    private GradientDrawable round(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private int dp(float value) {
        return (int)(value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
